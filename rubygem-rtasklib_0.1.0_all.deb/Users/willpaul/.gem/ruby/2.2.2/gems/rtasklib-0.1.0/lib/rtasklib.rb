require "rtasklib/version"

module Rtasklib
  # Your code goes here...
end
